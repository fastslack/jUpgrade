<?php
/**
 * @version		$Id: default_cache.php 15576 2010-03-25 12:43:26Z louis $
 * @package		Joomla.Administrator
 * @subpackage	com_config
 * @copyright	Copyright (C) 2005 - 2010 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;
?>
<div class="width-100">

<fieldset class="adminform">
	<legend><?php echo JText::_('COM_CONFIG_CACHE_SETTINGS'); ?></legend>
			<?php
			foreach ($this->form->getFieldset('cache') as $field):
			?>
					<?php echo $field->label; ?>
					<?php echo $field->input; ?>
			<?php
			endforeach;
			?>
		<?php if ($this->data['cache_handler'] == 'memcache' || $this->data['session_handler'] == 'memcache') : ?>

				<?php echo JText::_('COM_CONFIG_MEMCACHE_PERSISTENT'); ?>

				<?php echo $lists['memcache_persist']; ?>

				<?php echo JText::_('COM_CONFIG_MEMCACHE_COMPRESSION'); ?>

				<?php echo $lists['memcache_compress']; ?>


				<?php echo JText::_('COM_CONFIG_MEMCACHE_SERVER'); ?>

				<?php echo JText::_('COM_CONFIG_HOST'); ?>:
				<input class="text_area" type="text" name="memcache_settings[servers][0][host]" size="25" value="<?php echo @$this->data->memcache_settings['servers'][0]['host']; ?>" />

				<?php echo JText::_('COM_CONFIG_PORT'); ?>:
				<input class="text_area" type="text" name="memcache_settings[servers][0][port]" size="6" value="<?php echo @$this->data->memcache_settings['servers'][0]['port']; ?>" />

		<?php endif; ?>

</fieldset>
</div>
