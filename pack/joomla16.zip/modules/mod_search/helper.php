<?php
/**
 * @version		$Id: helper.php 18100 2010-07-12 11:58:02Z dextercowley $
 * @package		Joomla.Site
 * @subpackage	mod_search
 * @copyright	Copyright (C) 2005 - 2010 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// no direct access
defined('_JEXEC') or die;

class modSearchHelper
{
	function getSearchImage($button_text) {
		$img = JHTML::_('image','searchButton.gif', $button_text, NULL, true, true);
		return $img;
	}
}