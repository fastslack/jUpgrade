<?php defined('_JEXEC') or die; ?>
<?php echo $this->loadTemplate($this->type); ?>

