<?php
/**
 * @version		$Id: index.php 18650 2010-08-26 13:28:49Z ian $
 * @package		Joomla.Site
 * @copyright	Copyright (C) 2005 - 2010 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

include dirname(__FILE__).DIRECTORY_SEPARATOR.'component.php';