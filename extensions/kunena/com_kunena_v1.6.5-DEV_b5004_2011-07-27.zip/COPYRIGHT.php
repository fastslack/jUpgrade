<?php
/**
* @version $Id$
* Kunena Component
* @package Kunena
*
* @Copyright (C) 2008 - 2011 Kunena Team. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* @link http://www.kunena.org
*
* Based on FireBoard Component
* @Copyright (C) 2006 - 2007 Best Of Joomla All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* @link http://www.bestofjoomla.com
*/

// no direct access
defined( '_JEXEC' ) or die();

?>
<!--

Kunena derives from copyrighted works licensed under the GNU General
Public License.  This version has been modified pursuant to the
GNU General Public License as of September 15, 2005, and as distributed,
it includes or is derivative of works licensed under the GNU General
Public License or other free or open source software licenses, including
works copyrighted by any or all of the following, from 2000 through 2005:

TSMF & Jan de Graaff

Kunena includes or is derivative of works distributed under the following copyright notices:

mootools
----
Copyright:  2006-2008 [Valerio Proietti](http://mad4milk.net/).
License:    MIT license: http://www.opensource.org/licenses/mit-license.php

Nawte
----
Copyright:	2008 Jean-Nicolas Jolivet (www.silverscripting.com)
License:	MIT license: http://www.opensource.org/licenses/mit-license.php

 -->