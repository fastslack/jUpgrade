<?php
/**
*
* Description
*
* @package	VirtueMart
* @subpackage
* @author
* @link http://www.virtuemart.net
* @copyright Copyright (c) 2004 - 2011 VirtueMart Team. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
* VirtueMart is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* @version $Id: view.html.php 3087 2011-04-28 10:33:17Z Milbo $
*/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');

// Load the view framework
jimport( 'joomla.application.component.view');

/**
 * Default HTML View class for the VirtueMart Component
* @todo Find out how to use the front-end models instead of the backend models
 */
class VirtueMartViewVirtueMart extends JView {

	var $mediaModel = null;

	public function display($tpl = null) {

	    /* MULTI-X
	    * $this->loadHelper('vendorHelper');
	    * $vendorModel = new Vendor;
	    * $vendor = $vendorModel->getVendor();
	    * $this->assignRef('vendor',	$vendor);
	    */
	    $vendorId = JRequest::getInt('vendorid', 1);

	    $vendorModel = $this->getModel('vendor');

	    $vendorModel->setId(1);
	    $vendor = $vendorModel->getVendor();
	    $this->assignRef('vendor',$vendor);

		if(!VmConfig::get('shop_is_offline',0)){
		$categoryModel = $this->getModel('category');
		$productModel = $this->getModel('product');

	    $categoryId = JRequest::getInt('catid', 0);
        $categoryChildren = $categoryModel->getChildCategoryList($vendorId, $categoryId);
        $categoryModel->addImagesToCategories($categoryChildren);

        $this->assignRef('categories',	$categoryChildren);

        if(!class_exists('calculationHelper'))require(JPATH_VM_ADMINISTRATOR.DS.'helpers'.DS.'calculationh.php');

        /* Load the recent viewed products */
        if (VmConfig::get('show_recent', 1)) {
        	$recentProductIds = shopFunctionsF::getRecentProductIds();
			$recentProducts = $productModel->getProducts($recentProductIds);
        	$productModel->addImagesToProducts($recentProducts);
        	$this->assignRef('recentProducts', $recentProducts);
        }

        if (VmConfig::get('showFeatured', 1)) {
			$featuredProducts = & $productModel->getGroupProducts('featured', $vendorId, '', 5);
			$productModel->addImagesToProducts($featuredProducts);
			$this->assignRef('featuredProducts', $featuredProducts);
		}

		if (VmConfig::get('showlatest', 1)) {
			$latestProducts = & $productModel->getGroupProducts('latest', $vendorId, '', 5);
			$productModel->addImagesToProducts($latestProducts);
			$this->assignRef('latestProducts', $latestProducts);
		}

        if (VmConfig::get('showTopten', 1)) {
			$toptenProducts = & $productModel->getGroupProducts('topten', $vendorId, '', 5);
			$productModel->addImagesToProducts($toptenProducts);
			$this->assignRef('toptenProducts', $toptenProducts);
		}

		if(!class_exists('Permissions')) require(JPATH_VM_ADMINISTRATOR.DS.'helpers'.DS.'permissions.php');
		$showBasePrice = Permissions::getInstance()->check('admin'); //todo add config settings
		$this->assignRef('showBasePrice', $showBasePrice);

//		$layoutName = VmConfig::get('vmlayout','default');

		$layout = VmConfig::get('vmlayout','default');
		$this->setLayout($layout);

		if(!class_exists('CurrencyDisplay')) require(JPATH_VM_ADMINISTRATOR.DS.'helpers'.DS.'currencydisplay.php');
	    $this->assignRef('currencyDisplay',CurrencyDisplay::getCurrencyDisplay());

		} else {
			$this->setLayout('offline');
		}

		/* Set the titles */
		$document = JFactory::getDocument();
		$document->setTitle(JText::sprintf('COM_VIRTUEMART_HOME',$vendor->vendor_store_name));


		$template = VmConfig::get('vmtemplate','default');
		if (is_dir(JPATH_THEMES.DS.$template)) {
			$mainframe = JFactory::getApplication();
			$mainframe->set('setTemplate', $template);
		}

		parent::display($tpl);

	}

}
// pure php no closing tag