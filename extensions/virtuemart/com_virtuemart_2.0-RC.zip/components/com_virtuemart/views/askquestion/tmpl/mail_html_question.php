<?php
echo JText::sprintf('COM_VIRTUEMART_QUESTION_MAIL_MSG', $this->product->product_name, $this->comment);
