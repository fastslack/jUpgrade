-- Remove all required data

DELETE FROM `#__vm_perm_groups`;
DELETE FROM `#__vm_country`;
DELETE FROM `#__vm_creditcard`;
DELETE FROM `#__vm_currency`;
DELETE FROM `#__vm_payment_method`;
DELETE FROM `#__vm_shipping_carrier`;
DELETE FROM `#__vm_shipping_rate`;
DELETE FROM `#__vm_shopper_group`;
DELETE FROM `#__vm_user_shopper_group_xref`;
DELETE FROM `#__vm_state`;