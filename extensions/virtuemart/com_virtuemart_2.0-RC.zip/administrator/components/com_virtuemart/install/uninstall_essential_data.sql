-- Remove all essential data

DELETE FROM `#__vm_config`;
DELETE FROM `#__vm_menu_admin`;
DELETE FROM `#__vm_module`;
DELETE FROM `#__vm_order_status`;
DELETE FROM `#__vm_userfield`;
DELETE FROM `#__vm_userfield_values`;